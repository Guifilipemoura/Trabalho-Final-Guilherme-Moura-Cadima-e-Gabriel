﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bananza
{
    public partial class Form12 : Form
    {
        public enum Player
        {
             X, O
        }
        //chamar a classe do player

        Player currentPlayer;

        //criar lista

        List<Button> buttons;

        Random random = new Random();

        

        //set player win integer to 0


        //Set vitorias do computador para 0

        public Form12()
        {
            InitializeComponent();
            Reset();
        }

        private void player1Click(object sender, EventArgs e)
        {
            //encontrar os butoes clickados
            var button = (Button)sender;
            currentPlayer = Player.X;

            button.Text = currentPlayer.ToString();

            button.Enabled = false;

            //mudar cor

            button.BackColor = Color.Cyan;

            //remover o butao clickado

            buttons.Remove(button);

            //ver se o player ganhou
            CheckP();

            //startar timer do robô
            timer1.Start();
            
        }
        private void JogadaAI(object sender, EventArgs e)
        {
            if (buttons.Count > 0)
            {
                //generate a random number entre os botoes available
                int index = random.Next(buttons.Count);

                //assign the number ao botao
                buttons[index].Enabled = false;

                currentPlayer = Player.O;

                buttons[index].Text = currentPlayer.ToString();

                buttons[index].BackColor = Color.DarkSalmon;

                buttons.RemoveAt(index);
                CheckB();

                //parar timer AI
                timer1.Stop();
            }
        }

        private void Form12_Load(object sender, EventArgs e)
        {
            Program.playerWins = 0;
            Program.ComputerWins = 0;

        }

        

        private void carregarButoes()
        {
            buttons = new List<Button> { button1, button2, button3, button4, button5, button6, button7, button8, button9 };
        }

        private void Reset()
        {
            foreach (Control X in this.Controls)
            {
                if (X is Button && X.Tag == "Play")
                {
                    ((Button)X).Enabled = true;
                    ((Button)X).Text = "?";
                    ((Button)X).BackColor = Color.DarkGreen;
                }
            }
            carregarButoes();
        }

        private void CheckP()//PLAYER1
        {
            //ver se o player ganhou
            if (button1.Text == "X" && button2.Text == "X" && button3.Text == "X"
                || button4.Text == "X" && button5.Text == "X" && button6.Text == "X"
                || button7.Text == "X" && button8.Text == "X" && button9.Text == "X"
                || button1.Text == "X" && button4.Text == "X" && button7.Text == "X"
                || button2.Text == "X" && button5.Text == "X" && button8.Text == "X"
                || button3.Text == "X" && button6.Text == "X" && button9.Text == "X"
                || button1.Text == "X" && button5.Text == "X" && button9.Text == "X"
                || button3.Text == "X" && button5.Text == "X" && button7.Text == "X")
            {
                Program.Minijogos++;
                timer1.Stop();
                button1.Enabled = false;
                button2.Enabled = false;
                button3.Enabled = false;
                button4.Enabled = false;
                button5.Enabled = false;
                button6.Enabled = false;
                button7.Enabled = false;
                button8.Enabled = false;
                button9.Enabled = false;
                
                button10.Visible = true;
                Program.playerWins = 1;
                Program.condition = 3;
                Program.bananos = Program.bananos + 200;
                Program.bananosGanhos = 200;
            }
            else if (buttons.Count == 0)
            {
                button11.Visible = true;
            }
        }
        private void CheckB()//P2
        {
            if (button1.Text == "O" && button2.Text == "O" && button3.Text == "O"
                || button4.Text == "O" && button5.Text == "O" && button6.Text == "O"
                || button7.Text == "O" && button8.Text == "O" && button9.Text == "O"
                || button1.Text == "O" && button4.Text == "O" && button7.Text == "O"
                || button2.Text == "O" && button5.Text == "O" && button8.Text == "O"
                || button3.Text == "O" && button6.Text == "O" && button9.Text == "O"
                || button1.Text == "O" && button5.Text == "O" && button9.Text == "O"
                || button3.Text == "O" && button5.Text == "O" && button7.Text == "O")
            {
                button1.Enabled = false;
                button2.Enabled = false;
                button3.Enabled = false;
                button4.Enabled = false;
                button5.Enabled = false;
                button6.Enabled = false;
                button7.Enabled = false;
                button8.Enabled = false;
                button9.Enabled = false;
                button10.Visible = true;
                Program.ComputerWins = 1;
                Program.condition = 1;
            }
            else if (buttons.Count == 0)
            {
                button11.Visible = true;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }
        
        private void button10_Click(object sender, EventArgs e)
        {
            Form17 F17 = new Form17();
            this.Hide();
            F17.Show();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Form12 F12 = new Form12();
            this.Hide();
            F12.Show();
        }
    }
}
