﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bananza
{
    public partial class Form11 : Form
    {
        public Form11()
        {
            InitializeComponent();
        }

        private void Form11_Load(object sender, EventArgs e)
        {
            if (Program.condition <= 2)
            {
                pictureBox1.Image = Properties.Resources.banana3;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            /* Form12 F12 = new Form12();
             * this.hide();
             * F12.Show();*/ //ultimo quizz depois disto feito o program estará finalizado então é para trabalhar COMO ATUALIZAR A SHOP!!!
        }
    }
}
