﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bananza
{
    internal static class Program
    {
        //VIDA EXTRA (done) / ATUALIZAR JOGO DO GALO(done) / MULTIPLICADOR DE PONTOS OU MINIJOGOS (done) / LEADERBOARD PARA OS MINIJOGOS GANHOS(por fazer (CADIMA)) / Guessing Game (DONE) 
        /// mudar pra quiz de futebol (:/) / FAZER ECRÃ DEPOIS DE CADA MINIJOGO (done)
        public static int bananos = 0; // moeda que ira dar update
        public static int condition = 3; //derrota ou nao do utilizador
        public static int perguntasComida = 0;
        public static int vidinhas = 3;
        public static int QuizzGanhos = -1;
        public static int Banana_cr7 = 0;
        public static int Banana_builder = 0;
        public static int Banana_Mafia = 0;
        public static int vidas = 3;
        public static int bananadefault = 1;
        public static int MemoriaGuesses = 0;
        public static int playerWins = 0;
        public static int ComputerWins = 0;
        public static int Minijogos = 0;
        public static int bananaCR7inv = 0;
        public static int bananaMAFIAinv = 0;
        public static int bananaBUILDERinv = 0;
        public static int bananosGanhos = 0;
        public static int ExplicacaoDone = 0;
        public static int Variavel_GuessNumber;
        public static int NumberGuesses = 0;
        public static int NUMERO_GUESS;

        /// <summary>
        /// Ponto de entrada principal para o aplicativo.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
