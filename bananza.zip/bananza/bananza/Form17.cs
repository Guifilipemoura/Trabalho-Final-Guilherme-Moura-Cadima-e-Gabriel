﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bananza
{
    public partial class Form17 : Form
    {
        public Form17()
        {
            InitializeComponent();
        }

        private void Form17_Load(object sender, EventArgs e)
        {
            label2.Text = "Bananos ganhos: " + Program.bananosGanhos;
            label3.Text = "Bananos atuais: " + Program.bananos;
            if (Program.condition >= 3)
            {
                label4.Text = "Resultado: Vitória";
            }
            else
            {
                label4.Text = "Resultado: Derrota";
            }
                
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Form3 F3 = new Form3();
            this.Hide();
            F3.Show();
        }
    }
}
