﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bananza
{
    public partial class Form16 : Form
    {
        public Form16()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Program.Banana_cr7 = 0;
            Program.Banana_builder = 1;
            Program.bananadefault = 0;
            Program.Banana_Mafia = 0;
            button3.Enabled = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Program.Banana_cr7 = 1;
            Program.Banana_builder = 0;
            Program.bananadefault = 0;
            Program.Banana_Mafia = 0;
            button4.Enabled = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 F3 = new Form3();
            this.Hide();
            F3.Show();
        }

        

        private void button2_Click(object sender, EventArgs e)
        {
            Program.Banana_cr7 = 0;
            Program.Banana_builder = 0;
            Program.bananadefault = 0;
            Program.Banana_Mafia = 1;
            button2.Enabled = false;
        }

        private void Form16_Load(object sender, EventArgs e)
        {
            Program.condition = 5;
            if (Program.bananaCR7inv == 1 && Program.bananaMAFIAinv == 0 && Program.bananaBUILDERinv == 0)
            {
                button2.Enabled = false;
                button3.Enabled = false;
                button4.Enabled = false;
            }
            if (Program.bananaCR7inv == 1 && Program.bananaMAFIAinv == 1 && Program.bananaBUILDERinv == 0)
            {
                button2.Enabled = false;
                button3.Enabled = true;
                button4.Enabled = true;
            }
            if (Program.bananaCR7inv == 1 && Program.bananaMAFIAinv == 0 && Program.bananaBUILDERinv == 1)
            {
                button2.Enabled = false;
                button3.Enabled = true;
                button4.Enabled = true; 
            }
            if (Program.bananaCR7inv == 1 && Program.bananaMAFIAinv == 1 && Program.bananaBUILDERinv == 1)
            {
                button2.Enabled = true;
                button3.Enabled = true;
                button4.Enabled = true;
            }
            if (Program.bananaCR7inv == 0 && Program.bananaMAFIAinv == 0 && Program.bananaBUILDERinv == 0)
            {
                button2.Enabled = false;
                button3.Enabled = false;
                button4.Enabled = false;
            }
            if (Program.bananaCR7inv == 0 && Program.bananaMAFIAinv == 1 && Program.bananaBUILDERinv == 0)
            {
                button2.Enabled = false;
                button3.Enabled = false;
                button4.Enabled = false;
            }
            if (Program.bananaCR7inv == 0 && Program.bananaMAFIAinv == 1 && Program.bananaBUILDERinv == 1)
            {
                button2.Enabled = true;
                button3.Enabled = true;
                button4.Enabled = false;
            }
            if (Program.bananaCR7inv == 1 && Program.bananaMAFIAinv == 1 && Program.bananaBUILDERinv == 0)
            {
                button2.Enabled = true;
                button3.Enabled = false;
                button4.Enabled = true;

            }
            if (Program.bananaCR7inv == 0 && Program.bananaMAFIAinv == 0 && Program.bananaBUILDERinv == 1)
            {
                button2.Enabled = false;
                button3.Enabled = false;
                button4.Enabled = false;

            }
        }
        private void pictureBox5_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Esta banana dá uma vida extra a cada 3 Minijogos ganhos em vez de 5");
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Esta banana dá o dobro dos pontos de minijogos");
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Esta banana dá 300 extra bananos a cada minijogo");
        }
    }
}
