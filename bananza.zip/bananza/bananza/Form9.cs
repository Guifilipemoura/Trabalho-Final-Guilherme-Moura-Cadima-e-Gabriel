﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace bananza
{
    public partial class Form9 : Form
    {
        public Form9()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form9_Load(object sender, EventArgs e)
        {
            Program.condition = 4;
            Metodozao2();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            button3.BackColor = Color.Red;
            button2.BackColor = Color.Lime;
            pictureBox2.Show();
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            pictureBox4.Visible = true;
            Program.condition = Program.condition - 1;
            Program.perguntasComida = Program.perguntasComida + 1;


        }

        private void button2_Click(object sender, EventArgs e)
        {
            button2.BackColor = Color.Lime;
            button3.BackColor = Color.Red;
            button1.BackColor = Color.Red;
            button4.BackColor = Color.Red;
            pictureBox3.Show();
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            pictureBox4.Visible = true;
            Program.perguntasComida = Program.perguntasComida + 1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button1.BackColor = Color.Red;
            button2.BackColor = Color.Lime;
            pictureBox2.Show();
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            pictureBox4.Visible = true;
            Program.condition = Program.condition - 1;
            Program.perguntasComida = Program.perguntasComida + 1;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            button4.BackColor = Color.Red;
            button2.BackColor = Color.Lime;
            pictureBox2.Show();
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            pictureBox4.Visible = true;
            Program.condition = Program.condition - 1;
            Program.perguntasComida = Program.perguntasComida + 1;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            button4.BackColor = Color.Yellow;
            button3.BackColor = Color.Yellow;
            button2.BackColor = Color.Yellow;
            button1.BackColor = Color.Yellow;
            if (Program.perguntasComida > 4)
            {
                Program.perguntasComida = 0;
                
                
                if (Program.condition >= 3)
                {
                    Program.bananos = Program.bananos + 400;
                    Program.bananosGanhos = 400;
                    Program.Minijogos = Program.Minijogos + 1;
                    Form17 Form17 = new Form17();
                    this.Hide();
                    Form17.Show();
                }
                if (Program.condition <= 2)
                {
                    Form17 F17 = new Form17();
                    this.Hide();
                    F17.Show();
                }
            }
            else
            {
                Metodozao2();
            }
            
        }
        public void Metodozao2()
        {
            pictureBox2.Hide();
            pictureBox3.Hide();
            pictureBox4.Visible = false;
            button1.Enabled = true;
            button2.Enabled = true;
            button3.Enabled = true;
            button4.Enabled = true;
            Random rnd = new Random();
            int num = rnd.Next(1, 17);
            switch (num)
            {
                case 1:
                    button1.Visible = true;
                    button2.Visible = true;
                    button3.Visible = true;
                    button4.Visible = true;
                    label2.Text = "De que país vêm os Croissants?";
                    button1.Text = "France";
                    button2.Text = "Austria";
                    button3.Text = "Portugal";
                    button4.Text = "Estados \nUnidos";
                    button2.Location = new Point(43, 321);//SEMPRE O CERTO
                    button1.Location = new Point(167, 223);
                    button4.Location = new Point(167, 319);
                    button3.Location = new Point(43, 223);
                    break;
                case 2:
                    button1.Visible = true;
                    button2.Visible = true;
                    button3.Visible = true;
                    button4.Visible = true;
                    label2.Text = "Qual o Menu mais vendido do McDonalds";
                    button1.Text = "Big Mac";
                    button2.Text = "Batata\n frita";
                    button3.Text = "Happy Meal";
                    button4.Text = "MC Chicken";
                    button2.Location = new Point(43, 223);
                    button3.Location = new Point(167, 223);
                    button4.Location = new Point(167, 319);
                    button1.Location = new Point(43, 321);

                    break;
                case 3:
                    button1.Visible = true;
                    button2.Visible = true;
                    button3.Visible = true;
                    button4.Visible = true;
                    label2.Text = "De que país é que vem a Pizza?";
                    button1.Text = "France";
                    button2.Text = "Itália";
                    button3.Text = "Alemanha";
                    button4.Text = "India";
                    button2.Location = new Point(43, 223);
                    button3.Location = new Point(167, 223);
                    button4.Location = new Point(167, 319);
                    button1.Location = new Point(43, 321);
                    break;
                case 4:
                    label2.Text = "Morcegos são comestiveis?";
                    button3.Text = "Sim";
                    button2.Text = "Não";
                    button1.Hide();
                    button4.Hide();
                    button2.Location = new Point(43, 223);
                    button3.Location = new Point(43, 321);
                    break;
                case 5:
                    button1.Visible = true;
                    button2.Visible = true;
                    button3.Visible = true;
                    button4.Visible = true;
                    label2.Text = "Tomate é uma fruta!";
                    button2.Text = "Verdadeiro";
                    button3.Text = "Falso";
                    button1.Hide();
                    button4.Hide();
                    button2.Location = new Point(167, 223);
                    button3.Location = new Point(43, 223);
                    break;
                case 6:
                    button1.Visible = true;
                    button2.Visible = true;
                    button3.Visible = true;
                    button4.Visible = true;
                    label2.Text = "Francesinha leva queijo, ou não?";
                    button2.Text = "Sim";
                    button3.Text = "Não";
                    button1.Hide();
                    button4.Hide();
                    button2.Location = new Point(167, 319);
                    button3.Location = new Point(43, 319);
                    break;
                case 7:
                    button1.Visible = true;
                    button2.Visible = true;
                    button3.Visible = true;
                    button4.Visible = true;
                    label2.Text = "De que país é que vem a Mozarella?";
                    button1.Text = "France";
                    button2.Text = "Itália";
                    button3.Text = "Alemanha";
                    button4.Text = "India";
                    button2.Location = new Point(43, 223);
                    button3.Location = new Point(167, 223);
                    button4.Location = new Point(167, 319);
                    button1.Location = new Point(43, 321);
                    break;
                case 8:
                    button1.Visible = true;
                    button2.Visible = true;
                    button3.Visible = true;
                    button4.Visible = true;
                    label2.Text = "A Cenoura melhora a visão!";
                    button2.Text = "Falso";
                    button3.Text = "Verdadeiro";
                    button1.Hide();
                    button4.Hide();
                    button2.Location = new Point(43, 321);
                    button3.Location = new Point(43, 223);
                    break;
                case 9:
                    button1.Visible = true;
                    button2.Visible = true;
                    button3.Visible = true;
                    button4.Visible = true;
                    label2.Text = "Qual destas foi mais vendida?";
                    button1.Text = "Burger King";
                    button2.Text = "MC'Donalds";
                    button3.Text = "KFC";
                    button4.Text = "Pizza Hut";
                    button2.Location = new Point(167, 319);
                    button4.Location = new Point(167, 223);
                    button3.Location = new Point(43, 319);
                    button1.Location = new Point(43, 223);
                    break;
                case 10:
                    button1.Visible = true;
                    button2.Visible = true;
                    button3.Visible = true;
                    button4.Visible = true;
                    label2.Text = "Qual a bebida mais saudável? ";
                    button1.Text = "Coca-Cola";
                    button2.Text = "Chá verde";
                    button3.Text = "Sumo de Laranja";
                    button4.Text = "Um Bongo";
                    button2.Location = new Point(43, 321);
                    button3.Location = new Point(167, 223);
                    button4.Location = new Point(167, 319);
                    button1.Location = new Point(43, 223);

                    break;
                case 11:
                    button1.Visible = true;
                    button2.Visible = true;
                    button3.Visible = true;
                    button4.Visible = true;
                    label2.Text = "Quantos litros de água deve-se beber ao dia\n (Adulto)";
                    button1.Text = "1 Litro";
                    button2.Text = "2 Litros";
                    button3.Text = "1,5 Litros";
                    button4.Text = "Meio Litro";
                    button2.Location = new Point(43, 223);
                    button3.Location = new Point(167, 223);
                    button4.Location = new Point(167, 319);
                    button1.Location = new Point(43, 321);//43; 223 (BUTTON3), 167; 223(BUTTO2), 43; 321 (BUTTON1), 167; 319(BUTTON4)

                    break;
                case 12:
                    button1.Visible = true;
                    button2.Visible = true;
                    button3.Visible = true;
                    button4.Visible = true;
                    label2.Text = "Quantos litros de água deve-se beber ao dia\n (Adulto)";
                    button1.Text = "1 Litro";
                    button2.Text = "2 Litros";
                    button3.Text = "1,5 Litros";
                    button4.Text = "Meio Litro";
                    button2.Location = new Point(43, 223);
                    button3.Location = new Point(167, 223);
                    button4.Location = new Point(167, 319);
                    button1.Location = new Point(43, 321);
                    break;
                case 13:
                    button1.Visible = true;
                    button2.Visible = true;
                    button3.Visible = true;
                    button4.Visible = true;
                    label2.Text = "Quantas refeições deve-se fazer ao dia?";
                    button1.Text = "2";
                    button2.Text = "6";
                    button3.Text = "3";
                    button4.Text = "4";
                    button2.Location = new Point(43, 223);
                    button3.Location = new Point(167, 223);
                    button4.Location = new Point(167, 319);
                    button1.Location = new Point(43, 321);
                    break;
                case 14:
                    button1.Visible = true;
                    button2.Visible = true;
                    button3.Visible = true;
                    button4.Visible = true;
                    label2.Text = "Origem do sushi?";
                    button1.Text = "China";
                    button2.Text = "Japão";
                    button3.Text = "Coreia do Norte";
                    button4.Text = "Tailândia";
                    button2.Location = new Point(43, 223);
                    button1.Location = new Point(167, 223);
                    button4.Location = new Point(167, 319);
                    button3.Location = new Point(43, 321);
                    break;
                case 15:
                    button1.Visible = true;
                    button2.Visible = true;
                    button3.Visible = true;
                    button4.Visible = true;
                    label2.Text = "Fast-Food 2 vezes por semana faz mal?";
                    button3.Text = "Não";
                    button2.Text = "Sim";
                    button1.Hide();
                    button4.Hide();
                    button2.Location = new Point(43, 223);
                    button3.Location = new Point(167, 223);

                    break;
                default:
                    button1.Visible = true;
                    button2.Visible = true;
                    button3.Visible = true;
                    button4.Visible = true;
                    label2.Text = "O Medronho é utilizado para quê?";
                    button3.Text = "Comida";
                    button2.Text = "Bebidas";
                    button1.Hide();
                    button4.Hide();
                    button2.Location = new Point(43, 321);
                    button3.Location = new Point(167, 321);

                    break;
            }
        }
    }
}
