﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bananza
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            
        }

        private void Form8_Load(object sender, EventArgs e)
        {
            label2.Text = "" + Program.bananos;
            Program.condition = 5;
            if ((Program.Banana_builder == 1 || Program.bananaBUILDERinv == 1))
            {
                pictureBox4.Visible = false;
                label4.Visible = false;
                button2.Visible = false;
            }
            if ((Program.Banana_Mafia == 1 || Program.bananaMAFIAinv == 1))
            {
                pictureBox5.Visible = false;
                label5.Visible = false;
                button4.Visible = false;
            }
            if ((Program.Banana_cr7 == 1 || Program.bananaCR7inv == 1))
            {
                pictureBox3.Visible = false;
                label3.Visible = false;
                button3.Visible = false;
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 F3 = new Form3();
            this.Hide();
            F3.Show();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (Program.bananos >=800)
            {
                Program.bananos = Program.bananos - 800;
                    Program.Banana_builder = 1;
                    Program.Banana_cr7 = 0;
                    Program.Banana_Mafia = 0;
                    pictureBox4.Visible = false; 
                    label4.Visible = false;
                    button2.Visible = false;
                    Program.bananadefault = 0;
                    label2.Text = "" + Program.bananos;
                    Program.bananaBUILDERinv = 1;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (Program.bananos >= 2600)
            {
                Program.bananos = Program.bananos - 2600;
                    Program.Banana_builder = 0;
                    Program.Banana_cr7 = 1;
                    Program.Banana_Mafia = 0;
                    pictureBox3.Visible = false; 
                    label3.Visible = false;
                    button3.Visible = false;
                    Program.bananadefault = 0;
                    Program.bananaCR7inv = 1;
                
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (Program.bananos >= 1800)
            {
                Program.bananos = Program.bananos - 1800;
               // if ((pictureBox4.Visible == true) && (pictureBox3.Visible == true))
              //  {
                    Program.Banana_builder = 0;
                    Program.Banana_cr7 = 0;
                    Program.Banana_Mafia = 1;
                    pictureBox5.Visible = false;
                    label5.Visible = false;
                    button4.Visible = false;
                    Program.bananadefault = 0;
                    Program.bananaMAFIAinv = 1;
               // }
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
