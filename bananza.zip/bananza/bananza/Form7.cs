﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bananza
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            int num2 = rnd.Next(1, 5);
            switch (num2)
            {
                case 1:
                    Form4 F4 = new Form4();
                    this.Hide();
                    F4.Show();

                    break;
                case 2:
                    Form15 F15 = new Form15();
                    this.Hide();
                    F15.Show();
                    break;
                case 3:
                    Form19 F19 = new Form19();
                    this.Hide();
                    F19.Show();
                    break;
                default:
                    
                    Form14 F14 = new Form14(); // QUIZ DE FUTEBOL
                    this.Hide();
                    F14.Show();
                    break;
            }       
        }

        private void Form7_Load(object sender, EventArgs e)
        {
                pictureBox1.Visible = true;
            
        }
        public void Metodozao()
        {
            progressBar1.Visible = true;
            progressBar1.Maximum = 100000;
            progressBar1.Minimum = 0;
            progressBar1.Step = 1;
            progressBar1.Style = ProgressBarStyle.Continuous;

            for (int i = 0; i < 100000; i++)
            {
                pictureBox2.Visible = true;
                progressBar1.Value = i;
                button1.Hide();
                button2.Show();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Metodozao();
        }
    }
}
