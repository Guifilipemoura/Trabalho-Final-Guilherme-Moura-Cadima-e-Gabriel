﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bananza
{
    public partial class Form18 : Form
    {
        

        public Form18()
        {
            InitializeComponent();
        }

        private void Form18_Load(object sender, EventArgs e)
        {
            Program.NumberGuesses = 0;
            Program.Variavel_GuessNumber = 0;
            label2.Text = "Guesses: " + Program.NumberGuesses;
            Program.condition = 3;
            Random rnd = new Random();
            Program.NUMERO_GUESS = rnd.Next(1, 24);
            
        }
        public void Guess_Number()
        {
            switch (Program.NUMERO_GUESS)
            {
                case 1:
                    if ((Program.Variavel_GuessNumber > 1) && (Program.Variavel_GuessNumber < 5))
                    {
                        label1.Text = "Esta perto ta resposta";
                    }
                    if ((Program.Variavel_GuessNumber >= 5) && (Program.Variavel_GuessNumber < 10))
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber >= 10) && (Program.Variavel_GuessNumber < 26))
                    {
                        label1.Text = "Esta longe da resposta";
                    }
                    if (Program.Variavel_GuessNumber == Program.NUMERO_GUESS)
                    {
                        button2.Visible = true;
                        pictureBox2.Visible = false;
                        label4.Text = "" + Program.NUMERO_GUESS;
                        label4.Visible = true;
                        textBox1.Enabled = false;
                        label1.Visible = false;
                        button1.Visible = false;
                    }
                    break;
                case 2:
                    if ((Program.Variavel_GuessNumber >= 1) && (Program.Variavel_GuessNumber != 2) && (Program.Variavel_GuessNumber <= 5))
                    {
                        label1.Text = "Esta perto ta resposta";
                    }
                    if ((Program.Variavel_GuessNumber > 6) && (Program.Variavel_GuessNumber < 10))
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber >= 10) && (Program.Variavel_GuessNumber < 26))
                    {
                        label1.Text = "Esta longe da resposta";
                    }
                    if (Program.Variavel_GuessNumber == Program.NUMERO_GUESS)
                    {
                        button2.Visible = true;
                        pictureBox2.Visible = false;
                        label4.Text = "" + Program.NUMERO_GUESS;
                        label4.Visible = true;
                        textBox1.Enabled = false;
                        label1.Visible = false;
                        button1.Visible = false;
                    }
                    break;
                case 3:
                    if ((Program.Variavel_GuessNumber >= 1) && (Program.Variavel_GuessNumber != 3) && (Program.Variavel_GuessNumber <= 6))
                    {
                        label1.Text = "Esta perto ta resposta";
                    }
                    if ((Program.Variavel_GuessNumber > 6) && (Program.Variavel_GuessNumber < 10))
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber >= 10) && (Program.Variavel_GuessNumber < 26))
                    {
                        label1.Text = "Esta longe da resposta";
                    }
                    if (Program.Variavel_GuessNumber == Program.NUMERO_GUESS)
                    {
                        button2.Visible = true;
                        pictureBox2.Visible = false;
                        label4.Text = "" + Program.NUMERO_GUESS;
                        label4.Visible = true;
                        textBox1.Enabled = false;
                        label1.Visible = false;
                        button1.Visible = false;
                    }
                    break;
                case 4:
                    if (Program.Variavel_GuessNumber < 2)
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber >= 2) && (Program.Variavel_GuessNumber != 4) && (Program.Variavel_GuessNumber <= 7))
                    {
                        label1.Text = "Esta perto ta resposta";
                    }
                    if ((Program.Variavel_GuessNumber > 7) && (Program.Variavel_GuessNumber < 11))
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber >= 11) && (Program.Variavel_GuessNumber < 26))
                    {
                        label1.Text = "Esta longe da resposta";
                    }
                    if (Program.Variavel_GuessNumber == Program.NUMERO_GUESS)
                    {
                        button2.Visible = true;
                        pictureBox2.Visible = false;
                        label4.Text = "" + Program.NUMERO_GUESS;
                        label4.Visible = true;
                        textBox1.Enabled = false;
                        label1.Visible = false;
                        button1.Visible = false;
                    }
                    break;
                case 5:
                    if (Program.Variavel_GuessNumber < 3)
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber >= 3) && (Program.Variavel_GuessNumber != 5) && (Program.Variavel_GuessNumber <= 7))
                    {
                        label1.Text = "Esta perto ta resposta";
                    }
                    if ((Program.Variavel_GuessNumber > 7) && (Program.Variavel_GuessNumber < 12))
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber >= 12) && (Program.Variavel_GuessNumber < 26))
                    {
                        label1.Text = "Esta longe da resposta";
                    }
                    if (Program.Variavel_GuessNumber == Program.NUMERO_GUESS)
                    {
                        button2.Visible = true;
                        pictureBox2.Visible = false;
                        label4.Text = "" + Program.NUMERO_GUESS;
                        label4.Visible = true;
                        textBox1.Enabled = false;
                        label1.Visible = false;
                        button1.Visible = false;
                    }
                    break;
                case 6:
                    if (Program.Variavel_GuessNumber < 4)
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber >= 4) && (Program.Variavel_GuessNumber != 6) && (Program.Variavel_GuessNumber <= 8))
                    {
                        label1.Text = "Esta perto ta resposta";
                    }
                    if ((Program.Variavel_GuessNumber > 8) && (Program.Variavel_GuessNumber < 13))
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber >= 13) && (Program.Variavel_GuessNumber < 26))
                    {
                        label1.Text = "Esta longe da resposta";
                    }
                    if (Program.Variavel_GuessNumber == Program.NUMERO_GUESS)
                    {
                        button2.Visible = true;
                        pictureBox2.Visible = false;
                        label4.Text = "" + Program.NUMERO_GUESS;
                        label4.Visible = true;
                        textBox1.Enabled = false;
                        label1.Visible = false;
                        button1.Visible = false;
                    }
                    break;
                case 7:
                    if (Program.Variavel_GuessNumber < 5)
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber >= 5) && (Program.Variavel_GuessNumber != 7) && (Program.Variavel_GuessNumber <= 9))
                    {
                        label1.Text = "Esta perto ta resposta";
                    }
                    if ((Program.Variavel_GuessNumber > 9) && (Program.Variavel_GuessNumber < 14))
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber >= 14) && (Program.Variavel_GuessNumber < 26))
                    {
                        label1.Text = "Esta longe da resposta";
                    }
                    if (Program.Variavel_GuessNumber == Program.NUMERO_GUESS)
                    {
                        button2.Visible = true;
                        pictureBox2.Visible = false;
                        label4.Text = "" + Program.NUMERO_GUESS;
                        label4.Visible = true;
                        textBox1.Enabled = false;
                        label1.Visible = false;
                        button1.Visible = false;
                    }
                    break;
                case 8:
                    if (Program.Variavel_GuessNumber < 6)
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber >= 6) && (Program.Variavel_GuessNumber != 8) && (Program.Variavel_GuessNumber <= 10))
                    {
                        label1.Text = "Esta perto ta resposta";
                    }
                    if ((Program.Variavel_GuessNumber > 10) && (Program.Variavel_GuessNumber < 15))
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber >= 15) && (Program.Variavel_GuessNumber < 26))
                    {
                        label1.Text = "Esta longe da resposta";
                    }
                    if (Program.Variavel_GuessNumber == Program.NUMERO_GUESS)
                    {
                        button2.Visible = true;
                        pictureBox2.Visible = false;
                        label4.Text = "" + Program.NUMERO_GUESS;
                        label4.Visible = true;
                        textBox1.Enabled = false;
                        label1.Visible = false;
                        button1.Visible = false;
                    }
                    break;
                case 9:
                    if (Program.Variavel_GuessNumber <= 2)
                    {
                        label1.Text = "Esta longe da resposta";
                    }
                    if ((Program.Variavel_GuessNumber > 2) && Program.Variavel_GuessNumber < 7)
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber >= 7) && (Program.Variavel_GuessNumber != 9) && (Program.Variavel_GuessNumber <= 11))
                    {
                        label1.Text = "Esta perto ta resposta";
                    }
                    if ((Program.Variavel_GuessNumber > 11) && (Program.Variavel_GuessNumber <= 13))
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber > 13) && (Program.Variavel_GuessNumber < 26))
                    {
                        label1.Text = "Esta longe da resposta";
                    }
                    if (Program.Variavel_GuessNumber == Program.NUMERO_GUESS)
                    {
                        button2.Visible = true;
                        pictureBox2.Visible = false;
                        label4.Text = "" + Program.NUMERO_GUESS;
                        label4.Visible = true;
                        textBox1.Enabled = false;
                        label1.Visible = false;
                        button1.Visible = false;
                    }
                    break;
                case 10:
                    if (Program.Variavel_GuessNumber <= 2)
                    {
                        label1.Text = "Esta longe da resposta";
                    }
                    if ((Program.Variavel_GuessNumber > 2) && Program.Variavel_GuessNumber < 7)
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber >= 7) && (Program.Variavel_GuessNumber != 10) && (Program.Variavel_GuessNumber <= 13))
                    {
                        label1.Text = "Esta perto ta resposta";
                    }
                    if ((Program.Variavel_GuessNumber > 13) && (Program.Variavel_GuessNumber < 13))
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber >= 13) && (Program.Variavel_GuessNumber < 26))
                    {
                        label1.Text = "Esta longe da resposta";
                    }
                    if (Program.Variavel_GuessNumber == Program.NUMERO_GUESS)
                    {
                        button2.Visible = true;
                        pictureBox2.Visible = false;
                        label4.Text = "" + Program.NUMERO_GUESS;
                        label4.Visible = true;
                        textBox1.Enabled = false;
                        label1.Visible = false;
                        button1.Visible = false;
                    }
                    break;
                case 11:
                    if (Program.Variavel_GuessNumber <= 3)
                    {
                        label1.Text = "Esta longe da resposta";
                    }
                    if ((Program.Variavel_GuessNumber > 3) && Program.Variavel_GuessNumber < 8)
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber >= 8) && (Program.Variavel_GuessNumber != 11) && (Program.Variavel_GuessNumber <= 13))
                    {
                        label1.Text = "Esta perto ta resposta";
                    }
                    if ((Program.Variavel_GuessNumber > 13) && (Program.Variavel_GuessNumber <= 18))
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber > 18) && (Program.Variavel_GuessNumber < 26))
                    {
                        label1.Text = "Esta longe da resposta";
                    }
                    if (Program.Variavel_GuessNumber == Program.NUMERO_GUESS)
                    {
                        button2.Visible = true;
                        pictureBox2.Visible = false;
                        label4.Text = "" + Program.NUMERO_GUESS;
                        label4.Visible = true;
                        textBox1.Enabled = false;
                        label1.Visible = false;
                        button1.Visible = false;
                    }
                    break;
                case 12:
                    if (Program.Variavel_GuessNumber <= 3)
                    {
                        label1.Text = "Esta longe da resposta";
                    }
                    if ((Program.Variavel_GuessNumber > 3) && Program.Variavel_GuessNumber < 8)
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber >= 8) && (Program.Variavel_GuessNumber != 12) && (Program.Variavel_GuessNumber <= 14))
                    {
                        label1.Text = "Esta perto ta resposta";
                    }
                    if ((Program.Variavel_GuessNumber > 14) && (Program.Variavel_GuessNumber < 18))
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber >= 18) && (Program.Variavel_GuessNumber < 26))
                    {
                        label1.Text = "Esta longe da resposta";
                    }
                    if (Program.Variavel_GuessNumber == Program.NUMERO_GUESS)
                    {
                        button2.Visible = true;
                        pictureBox2.Visible = false;
                        label4.Text = "" + Program.NUMERO_GUESS;
                        label4.Visible = true;
                        textBox1.Enabled = false;
                        label1.Visible = false;
                        button1.Visible = false;
                    }
                    break;
                case 13:
                    if (Program.Variavel_GuessNumber <= 4)
                    {
                        label1.Text = "Esta longe da resposta";
                    }
                    if ((Program.Variavel_GuessNumber > 4) && Program.Variavel_GuessNumber < 9)
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber > 9) && (Program.Variavel_GuessNumber != 13) && (Program.Variavel_GuessNumber < 15))
                    {
                        label1.Text = "Esta perto ta resposta";
                    }
                    if ((Program.Variavel_GuessNumber > 15) && (Program.Variavel_GuessNumber < 19))
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber > 19) && (Program.Variavel_GuessNumber < 26))
                    {
                        label1.Text = "Esta longe da resposta";
                    }
                    if (Program.Variavel_GuessNumber == Program.NUMERO_GUESS)
                    {
                        button2.Visible = true;
                        pictureBox2.Visible = false;
                        label4.Text = "" + Program.NUMERO_GUESS;
                        label4.Visible = true;
                        textBox1.Enabled = false;
                        label1.Visible = false;
                        button1.Visible = false;
                    }
                    break;
                case 14:
                    if (Program.Variavel_GuessNumber <= 5)
                    {
                        label1.Text = "Esta longe da resposta";
                    }
                    if ((Program.Variavel_GuessNumber > 5) && Program.Variavel_GuessNumber < 10)
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber >= 10) && (Program.Variavel_GuessNumber != 14) && (Program.Variavel_GuessNumber < 16))
                    {
                        label1.Text = "Esta perto ta resposta";
                    }
                    if ((Program.Variavel_GuessNumber >= 16) && (Program.Variavel_GuessNumber < 20))
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber > 20) && (Program.Variavel_GuessNumber < 26))
                    {
                        label1.Text = "Esta longe da resposta";
                    }
                    if (Program.Variavel_GuessNumber == Program.NUMERO_GUESS)
                    {
                        button2.Visible = true;
                        pictureBox2.Visible = false;
                        label4.Text = "" + Program.NUMERO_GUESS;
                        label4.Visible = true;
                        textBox1.Enabled = false;
                        label1.Visible = false;
                        button1.Visible = false;
                    }
                    break;
                case 15:
                    if (Program.Variavel_GuessNumber <= 5)
                    {
                        label1.Text = "Esta longe da resposta";
                    }
                    if ((Program.Variavel_GuessNumber > 5) && Program.Variavel_GuessNumber < 10)
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber >= 10) && (Program.Variavel_GuessNumber != 15) && (Program.Variavel_GuessNumber <= 17))
                    {
                        label1.Text = "Esta perto ta resposta";
                    }
                    if ((Program.Variavel_GuessNumber > 17) && (Program.Variavel_GuessNumber < 20))
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber >= 20) && (Program.Variavel_GuessNumber < 26))
                    {
                        label1.Text = "Esta longe da resposta";
                    }
                    if (Program.Variavel_GuessNumber == Program.NUMERO_GUESS)
                    {
                        button2.Visible = true;
                        pictureBox2.Visible = false;
                        label4.Text = "" + Program.NUMERO_GUESS;
                        label4.Visible = true;
                        textBox1.Enabled = false;
                        label1.Visible = false;
                        button1.Visible = false;
                    }
                    break;
                case 16:
                    if (Program.Variavel_GuessNumber <= 5)
                    {
                        label1.Text = "Esta longe da resposta";
                    }
                    if ((Program.Variavel_GuessNumber > 5) && Program.Variavel_GuessNumber < 12)
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber >= 12) && (Program.Variavel_GuessNumber != 16) && (Program.Variavel_GuessNumber < 18))
                    {
                        label1.Text = "Esta perto ta resposta";
                    }
                    if ((Program.Variavel_GuessNumber >= 18) && (Program.Variavel_GuessNumber < 22))
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber >= 22) && (Program.Variavel_GuessNumber < 26))
                    {
                        label1.Text = "Esta longe da resposta";
                    }
                    if (Program.Variavel_GuessNumber == Program.NUMERO_GUESS)
                    {
                        button2.Visible = true;
                        pictureBox2.Visible = false;
                        label4.Text = "" + Program.NUMERO_GUESS;
                        label4.Visible = true;
                        textBox1.Enabled = false;
                        label1.Visible = false;
                        button1.Visible = false;
                    }
                    break;
                case 17:
                    if (Program.Variavel_GuessNumber <= 6)
                    {
                        label1.Text = "Esta longe da resposta";
                    }
                    if ((Program.Variavel_GuessNumber > 6) && Program.Variavel_GuessNumber < 14)
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber >= 14) && (Program.Variavel_GuessNumber != 17) && (Program.Variavel_GuessNumber <= 20))
                    {
                        label1.Text = "Esta perto ta resposta";
                    }
                    if ((Program.Variavel_GuessNumber > 20) && (Program.Variavel_GuessNumber < 22))
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber >= 22) && (Program.Variavel_GuessNumber < 26))
                    {
                        label1.Text = "Esta longe da resposta";
                    }
                    if (Program.Variavel_GuessNumber == Program.NUMERO_GUESS)
                    {
                        button2.Visible = true;
                        pictureBox2.Visible = false;
                        label4.Text = "" + Program.NUMERO_GUESS;
                        label4.Visible = true;
                        textBox1.Enabled = false;
                        button1.Visible = false;
                        label1.Visible = false;
                    }
                    break;
                case 18:
                    if (Program.Variavel_GuessNumber <= 7)
                    {
                        label1.Text = "Esta longe da resposta";
                    }
                    if ((Program.Variavel_GuessNumber > 7) && Program.Variavel_GuessNumber < 15)
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber >= 15) && (Program.Variavel_GuessNumber != 18) && (Program.Variavel_GuessNumber <= 21))
                    {
                        label1.Text = "Esta perto ta resposta";
                    }
                    if ((Program.Variavel_GuessNumber > 21) && (Program.Variavel_GuessNumber < 26))
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if (Program.Variavel_GuessNumber == Program.NUMERO_GUESS)
                    {
                        button2.Visible = true;
                        pictureBox2.Visible = false;
                        label4.Text = "" + Program.NUMERO_GUESS;
                        label4.Visible = true;
                        textBox1.Enabled = false;
                        label1.Visible = false;
                        button1.Visible = false;
                    }
                    break;
                case 19:
                    if (Program.Variavel_GuessNumber <= 8)
                    {
                        label1.Text = "Esta longe da resposta";
                    }
                    if ((Program.Variavel_GuessNumber > 8) && Program.Variavel_GuessNumber < 16)
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber >= 16) && (Program.Variavel_GuessNumber != 19) && (Program.Variavel_GuessNumber < 22))
                    {
                        label1.Text = "Esta perto ta resposta";
                    }
                    if ((Program.Variavel_GuessNumber > 22) && (Program.Variavel_GuessNumber < 26))
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if (Program.Variavel_GuessNumber == Program.NUMERO_GUESS)
                    {
                        button2.Visible = true;
                        pictureBox2.Visible = false;
                        label4.Text = "" + Program.NUMERO_GUESS;
                        label4.Visible = true;
                        textBox1.Enabled = false;
                        label1.Visible = false;
                        button1.Visible = false;
                    }
                    break;
                case 20:
                    if (Program.Variavel_GuessNumber <= 9)
                    {
                        label1.Text = "Esta longe da resposta";
                    }
                    if ((Program.Variavel_GuessNumber > 9) && Program.Variavel_GuessNumber < 17)
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber >= 17) && (Program.Variavel_GuessNumber != 20) && (Program.Variavel_GuessNumber <= 23))
                    {
                        label1.Text = "Esta perto ta resposta";
                    }
                    if ((Program.Variavel_GuessNumber > 23) && (Program.Variavel_GuessNumber < 26))
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if (Program.Variavel_GuessNumber == Program.NUMERO_GUESS)
                    {
                        button2.Visible = true;
                        pictureBox2.Visible = false;
                        label4.Text = "" + Program.NUMERO_GUESS;
                        label4.Visible = true;
                        textBox1.Enabled = false;
                        label1.Visible = false;
                        button1.Visible = false;
                    }
                    break;
                case 21:
                    if (Program.Variavel_GuessNumber <= 10)
                    {
                        label1.Text = "Esta longe da resposta";
                    }
                    if ((Program.Variavel_GuessNumber > 10) && Program.Variavel_GuessNumber < 18)
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber >= 18) && (Program.Variavel_GuessNumber != 21) && (Program.Variavel_GuessNumber < 24))
                    {
                        label1.Text = "Esta perto ta resposta";
                    }
                    if ((Program.Variavel_GuessNumber >= 24) && (Program.Variavel_GuessNumber < 26))
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if (Program.Variavel_GuessNumber == Program.NUMERO_GUESS)
                    {
                        button2.Visible = true;
                        pictureBox2.Visible = false;
                        label4.Text = "" + Program.NUMERO_GUESS;
                        label4.Visible = true;
                        textBox1.Enabled = false;
                        label1.Visible = false;
                        button1.Visible = false;
                    }
                    break;
                case 22:
                    if (Program.Variavel_GuessNumber <= 13)
                    {
                        label1.Text = "Esta longe da resposta";
                    }
                    if ((Program.Variavel_GuessNumber > 13) && Program.Variavel_GuessNumber < 19)
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber >= 19) && (Program.Variavel_GuessNumber != 22) && (Program.Variavel_GuessNumber < 25))
                    {
                        label1.Text = "Esta perto ta resposta";
                    }
                    if ((Program.Variavel_GuessNumber > 25) && (Program.Variavel_GuessNumber < 26))
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if (Program.Variavel_GuessNumber == Program.NUMERO_GUESS)
                    {
                        button2.Visible = true;
                        pictureBox2.Visible = false;
                        label4.Text = "" + Program.NUMERO_GUESS;
                        label4.Visible = true;
                        textBox1.Enabled = false;
                        label1.Visible = false;
                        button1.Visible = false;
                    }
                    break;
                case 23:
                    if (Program.Variavel_GuessNumber <= 13)
                    {
                        label1.Text = "Esta longe da resposta";
                    }
                    if ((Program.Variavel_GuessNumber > 13) && Program.Variavel_GuessNumber < 19)
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber >= 19) && (Program.Variavel_GuessNumber != 23) && (Program.Variavel_GuessNumber < 25))
                    {
                        label1.Text = "Esta perto ta resposta";
                    }
                    if (Program.Variavel_GuessNumber == 25) 
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if (Program.Variavel_GuessNumber == Program.NUMERO_GUESS)
                    {
                        button2.Visible = true;
                        pictureBox2.Visible = false;
                        label4.Text = "" + Program.NUMERO_GUESS;
                        label4.Visible = true;
                        textBox1.Enabled = false;
                        label1.Visible = false;
                        button1.Visible = false;
                    }
                    break;
                case 24:
                    if (Program.Variavel_GuessNumber <= 15)
                    {
                        label1.Text = "Esta longe da resposta";
                    }
                    if ((Program.Variavel_GuessNumber > 15) && Program.Variavel_GuessNumber < 21)
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber > 21) && (Program.Variavel_GuessNumber != 24) && (Program.Variavel_GuessNumber < 26))
                    {
                        label1.Text = "Esta perto ta resposta";
                    }
                    if (Program.Variavel_GuessNumber == Program.NUMERO_GUESS)
                    {
                        button2.Visible = true;
                        pictureBox2.Visible = false;
                        label4.Text = "" + Program.NUMERO_GUESS;
                        label4.Visible = true;
                        textBox1.Enabled = false;
                        label1.Visible = false;
                        button1.Visible = false;
                    }
                    break;
                case 25:
                    if (Program.Variavel_GuessNumber <= 10)
                    {
                        label1.Text = "Esta longe da resposta";
                    }
                    if ((Program.Variavel_GuessNumber > 10) && Program.Variavel_GuessNumber < 21)
                    {
                        label1.Text = "Esta um pouco longe da respota";
                    }
                    if ((Program.Variavel_GuessNumber > 21) && (Program.Variavel_GuessNumber != 25) && (Program.Variavel_GuessNumber < 26))
                    {
                        label1.Text = "Esta perto ta resposta";
                    }
                    if (Program.Variavel_GuessNumber == Program.NUMERO_GUESS)
                    {
                        button2.Visible = true;
                        pictureBox2.Visible = false;
                        label4.Text = "" + Program.NUMERO_GUESS;
                        label4.Visible = true;
                        textBox1.Enabled = false;
                        label1.Visible = false;
                        button1.Visible = false;
                    }
                    break;
                default:
                    break;

            }
                
        }
         
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Program.Variavel_GuessNumber = Convert.ToInt32(textBox1.Text);

            }
            catch
            {

            }

            finally
            {
                Guess_Number();
                Program.NumberGuesses = Program.NumberGuesses + 1;
                label2.Text = "Guesses: " + Program.NumberGuesses;
            }
         
            /*Guess_Number();
                Program.NumberGuesses = Program.NumberGuesses + 1;
                label2.Text = "Guesses: " + Program.NumberGuesses;*/
            

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (Program.NumberGuesses > 5)
            {
                Program.condition = 2;
                Form17 F17 = new Form17();
                this.Hide();
                F17.Show();
            }
            if (Program.NumberGuesses <= 5)
            {
                Program.condition = 3;
                Program.bananos = Program.bananos + 400;
                Program.bananosGanhos = 400;
                Form17 F17 = new Form17();
                this.Hide();
                F17.Show();
                Program.Minijogos = Program.Minijogos + 1;
            }

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
