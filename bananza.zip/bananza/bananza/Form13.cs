﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bananza
{
    public partial class Form13 : Form
    {
        Random random = new Random();

        List<string> icones = new List<string>()
        {
        "d", "d", "N", "N", ",", ",", "k", "k",
        "b", "b", "v", "v", "w", "w", "z", "z"
        };


        Label firstClicked, secondClicked;

        public Form13()
        {
            InitializeComponent();
        }

        public void MetodoMemoria()
        {

            Label label;
            int randomNumber;

            for (int i = 0; i < tableLayoutPanel1.Controls.Count; i++)
            {
                if (tableLayoutPanel1.Controls[i] is Label)
                    label = (Label)tableLayoutPanel1.Controls[i];
                else
                    continue;

                randomNumber = random.Next(0, icones.Count);
                label.Text = icones[randomNumber];

                icones.RemoveAt(randomNumber);
            }
        }

        private void label_Click(object sender, EventArgs e)
        {
            if (firstClicked != null && secondClicked != null)
                return;

            Label clickedLabel = sender as Label;

            if (clickedLabel == null)
                return;
            if (clickedLabel.ForeColor == Color.Black)
                return;
            if (firstClicked == null)
            {
                firstClicked = clickedLabel;
                firstClicked.ForeColor = Color.Black;
                return;
            }

            secondClicked = clickedLabel;
            secondClicked.ForeColor = Color.Black;
            Program.MemoriaGuesses = Program.MemoriaGuesses + 1;
            label17.Text = "Guesses: " + Program.MemoriaGuesses;

            Ganhar();

            if(firstClicked.Text == secondClicked.Text)
            {
                firstClicked = null;
                secondClicked = null;
            }
            else
                timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();

            firstClicked.ForeColor = firstClicked.BackColor;
            secondClicked.ForeColor = secondClicked.BackColor;

            firstClicked = null;
            secondClicked = null;
            
        }

        

        private void Form13_Load(object sender, EventArgs e)
        {
            Program.MemoriaGuesses = 0;
            MetodoMemoria();
            label17.Location = new Point(12, 477);
            
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form17 F17 = new Form17();// FORM DO ECRA DE DERROTA
            this.Hide();
            F17.Show();
        }

        private void Ganhar()
        {
            Label label;

            for (int i = 0; i < tableLayoutPanel1.Controls.Count; i++)
            {
                label = tableLayoutPanel1.Controls[i] as Label;

                if (label != null && label.ForeColor == label.BackColor)
                    return;
            }

            if (Program.MemoriaGuesses <= 15)
            {
                    button1.Visible = true;
                    Program.condition = 3;
                    Program.bananos = Program.bananos + 600;
                    Program.Minijogos = Program.Minijogos + 1;
                    Program.bananosGanhos = 600;
            }
            else
            {
                    Program.condition = 1;
                    button1.Visible = true;
                    Program.bananos = Program.bananos + 200;
                    Program.bananosGanhos = 200;
            }
        }
    }
}
