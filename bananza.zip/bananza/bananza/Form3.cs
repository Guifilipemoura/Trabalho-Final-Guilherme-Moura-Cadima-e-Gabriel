﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bananza
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            Program.bananosGanhos = 0;
            if(Program.Banana_cr7 == 1)
            {
                if (Program.Minijogos == 5)
                {
                    Program.vidinhas = Program.vidinhas + 1;
                    Program.Minijogos = 0;

                }
                pictureBox1.Image = Properties.Resources.bananacr7;
                if (Program.condition == 3 || Program.condition == 4)
                {
                    Program.QuizzGanhos = Program.QuizzGanhos + 2;

                }
                if (Program.condition <= 2)
                {
                    Program.vidinhas = Program.vidinhas - 1;

                }
                if (Program.vidinhas >=3)
                {
                    pictureBox1.Image = Properties.Resources.bananacr7;
                }
                if (Program.vidinhas == 2)
                {
                    pictureBox1.Image = Properties.Resources.bananacr7_2;
                    pictureBox1.SizeMode = PictureBoxSizeMode.CenterImage;
                }
                if (Program.vidinhas == 1)
                {
                    pictureBox1.Image = Properties.Resources.bananacr7_3;
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                }
                label1.Text = "MiniJogos ganhos: " + Program.QuizzGanhos;
                label2.Text = "Vidas: " + Program.vidinhas;
                if (Program.vidinhas == 0)
                {
                    Form6 F6 = new Form6();// FORM DO ECRA DE DERROTA
                    fechar();
                    F6.Show();
                }
            }
            if (Program.Banana_builder == 1)
            {
                Program.bananos = Program.bananos + 300;
                pictureBox1.Image = Properties.Resources.Banana_builder;
                if (Program.Minijogos == 5)
                {
                    Program.vidinhas = Program.vidinhas + 1;
                    Program.Minijogos = 0;

                }
                if (Program.condition == 3 || Program.condition == 4)
                    {
                        Program.QuizzGanhos = Program.QuizzGanhos + 1;

                }
                if (Program.condition <= 2)
                {
                    Program.vidinhas = Program.vidinhas - 1;

                }
                if (Program.vidinhas >= 3)
                {
                    pictureBox1.Image = Properties.Resources.Banana_builder;
                }
                if (Program.vidinhas == 2)
                {
                    pictureBox1.Image = Properties.Resources.Banana_Builder2;
                    pictureBox1.SizeMode = PictureBoxSizeMode.CenterImage;
                }
                if (Program.vidinhas == 1)
                {
                    pictureBox1.Image = Properties.Resources.Banana_Builder3;
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                }
                label1.Text = "MiniJogos ganhos: " + Program.QuizzGanhos;
                label2.Text = "Vidas: " + Program.vidinhas;
                if (Program.vidinhas == 0)
                {
                    Form6 F6 = new Form6();// FORM DO ECRA DE DERROTA
                    fechar();
                    F6.Show();
                }
            }
            if (Program.Banana_Mafia == 1)
            {
                if (Program.Minijogos == 3)
                {
                    Program.vidinhas = Program.vidinhas + 1;
                    Program.Minijogos = 0;

                }
                pictureBox1.Image = Properties.Resources.Banana_Mafia1;
                if (Program.condition == 3 || Program.condition == 4)
                {
                    Program.QuizzGanhos = Program.QuizzGanhos + 1;

                }
                if (Program.condition <= 2)
                {
                    Program.vidinhas = Program.vidinhas - 1;

                }
                if (Program.vidinhas >= 3)
                {
                    pictureBox1.Image = Properties.Resources.Banana_Mafia1;
                }
                if (Program.vidinhas == 2)
                {
                    pictureBox1.Image = Properties.Resources.Banana_Mafia2;
                    pictureBox1.SizeMode = PictureBoxSizeMode.CenterImage;
                }
                if (Program.vidinhas == 1)
                {
                    pictureBox1.Image = Properties.Resources.Banana_Mafia3;
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                }
                label1.Text = "MiniJogos ganhos: " + Program.QuizzGanhos;
                label2.Text = "Vidas: " + Program.vidinhas;
                if (Program.vidinhas == 0)
                {
                    Form6 F6 = new Form6();// FORM DO ECRA DE DERROTA
                    fechar();
                    F6.Show();
                }
            }
            if (Program.bananadefault == 1)
            {
                if (Program.Minijogos == 5)
                {
                    Program.vidinhas = Program.vidinhas + 1;
                    Program.Minijogos = 0;

                }
                if (Program.condition == 3 || Program.condition == 4)
                {
                    Program.QuizzGanhos = Program.QuizzGanhos + 1;

                }
                if (Program.condition <= 2)
                {
                    Program.vidinhas = Program.vidinhas - 1;

                }
                if (Program.vidinhas >= 3)
                {
                    pictureBox1.Image = Properties.Resources.banana1;
                }
                if (Program.vidinhas == 2)
                {
                    pictureBox1.Image = Properties.Resources.banana2;
                    pictureBox1.SizeMode = PictureBoxSizeMode.CenterImage;
                }
                if (Program.vidinhas == 1)
                {
                    pictureBox1.Image = Properties.Resources.banana3;
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                }
                label1.Text = "MiniJogos ganhos: " + Program.QuizzGanhos;
                label2.Text = "Vidas: " + Program.vidinhas;
                if (Program.vidinhas == 0)
                {
                    Form6 F6 = new Form6();// FORM DO ECRA DE DERROTA
                    fechar();
                    F6.Show();
                }
            }
            
        }
        private void fechar()
        {
            this.Close();
        } 
        private void button2_Click(object sender, EventArgs e)
        {
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form7 F7 = new Form7();
            this.Hide();
            F7.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form8 F8 = new Form8();
            this.Hide();
            F8.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Form16 F16 = new Form16();
            this.Hide();
            F16.Show();
        }
    }
}
